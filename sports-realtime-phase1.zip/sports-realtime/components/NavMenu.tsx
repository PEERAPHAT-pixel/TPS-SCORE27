export type NavMenuItem = {
  id: string;
  label: string;
};

/**
 * Phase 1: ยังไม่มีข้อมูลกีฬาจากฐานข้อมูล จึงมีเพียงแท็บ "ทั้งหมด"
 * Phase 2+ จะส่ง items จริงจากตาราง sports เข้ามาแทนค่า default นี้
 */
const DEFAULT_ITEMS: NavMenuItem[] = [{ id: "all", label: "ทั้งหมด" }];

export default function NavMenu({
  items = DEFAULT_ITEMS,
  activeId = "all",
}: {
  items?: NavMenuItem[];
  activeId?: string;
}) {
  return (
    <nav aria-label="กรองประเภทกีฬา" className="border-b border-line bg-white">
      <div className="mx-auto flex w-full max-w-5xl gap-1 overflow-x-auto px-4 sm:px-6 lg:px-8">
        {items.map((item) => {
          const isActive = item.id === activeId;
          return (
            <button
              key={item.id}
              type="button"
              aria-current={isActive ? "page" : undefined}
              disabled={items.length === 1}
              className={[
                "shrink-0 whitespace-nowrap border-b-2 px-4 py-3 font-display text-sm font-medium transition disabled:cursor-default",
                isActive
                  ? "border-amber-500 text-navy-900"
                  : "border-transparent text-muted hover:text-navy-900",
              ].join(" ")}
            >
              {item.label}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
