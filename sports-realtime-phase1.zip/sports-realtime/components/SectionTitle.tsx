export default function SectionTitle({
  children,
  action,
}: {
  children: React.ReactNode;
  action?: React.ReactNode;
}) {
  return (
    <div className="mb-4 mt-8 flex items-center justify-between border-b border-line pb-3">
      <h2 className="font-display text-lg font-semibold text-navy-900 sm:text-xl">
        {children}
      </h2>
      {action}
    </div>
  );
}
