const MENU_GROUPS = [
  {
    label: "ภาพรวม",
    items: [{ name: "ทั้งหมด", active: true }],
  },
  {
    label: "จัดการข้อมูล",
    items: [
      { name: "กีฬา", active: false },
      { name: "ทีม", active: false },
      { name: "การแข่งขัน", active: false },
    ],
  },
  {
    label: "สรุปผล",
    items: [
      { name: "ตารางคะแนนรวม", active: false },
      { name: "สรุปเหรียญ", active: false },
    ],
  },
];

export default function AdminSidebar() {
  return (
    <aside className="w-full shrink-0 bg-navy-950 text-white sm:w-56">
      <div className="px-5 py-5">
        <p className="font-display text-sm font-semibold tracking-wide text-white">
          Admin Panel
        </p>
        <p className="mt-0.5 text-xs text-white/40">ระบบจัดการหลังบ้าน</p>
      </div>

      <nav className="flex flex-col gap-5 px-3 pb-6">
        {MENU_GROUPS.map((group) => (
          <div key={group.label}>
            <p className="px-2 pb-2 text-[11px] font-medium uppercase tracking-[0.15em] text-white/35">
              {group.label}
            </p>
            <ul className="flex flex-col gap-0.5">
              {group.items.map((item) => (
                <li key={item.name}>
                  <div
                    aria-current={item.active ? "page" : undefined}
                    className={[
                      "flex items-center justify-between rounded-sm px-3 py-2 font-body text-sm",
                      item.active
                        ? "bg-white/10 text-white"
                        : "text-white/50",
                    ].join(" ")}
                  >
                    <span>{item.name}</span>
                    {!item.active && (
                      <span className="rounded-full bg-white/10 px-2 py-0.5 text-[10px] text-white/40">
                        เร็วๆ นี้
                      </span>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </nav>
    </aside>
  );
}
