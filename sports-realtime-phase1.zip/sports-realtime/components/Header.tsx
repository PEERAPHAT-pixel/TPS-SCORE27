import Link from "next/link";

const COMPETITION_NAME = "ระบบรายงานผลการแข่งขันกีฬา";

export default function Header() {
  return (
    <header className="bg-navy-900 text-white">
      <div className="mx-auto flex w-full max-w-5xl items-center justify-between px-4 py-5 sm:px-6 lg:px-8">
        <Link href="/" className="group flex items-center gap-3">
          <span
            aria-hidden
            className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-sm border-2 border-amber-500 font-display text-sm font-bold text-amber-500"
          >
            ⚑
          </span>
          <span className="font-display text-lg font-semibold tracking-wide sm:text-xl">
            {COMPETITION_NAME}
          </span>
        </Link>

        <Link
          href="/admin/login"
          className="rounded-sm border border-white/20 px-3 py-1.5 text-xs font-medium text-white/70 transition hover:border-white/40 hover:text-white sm:text-sm"
        >
          สำหรับผู้ดูแลระบบ
        </Link>
      </div>
    </header>
  );
}
