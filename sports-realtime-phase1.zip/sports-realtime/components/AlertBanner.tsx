type Tone = "error" | "success" | "info";

const TONE_CLASSES: Record<Tone, string> = {
  error: "border-rose-500/30 bg-rose-500/5 text-rose-500",
  success: "border-emerald-500/30 bg-emerald-500/5 text-emerald-600",
  info: "border-navy-900/15 bg-navy-900/5 text-navy-900",
};

export default function AlertBanner({
  tone = "info",
  children,
}: {
  tone?: Tone;
  children: React.ReactNode;
}) {
  return (
    <div
      role={tone === "error" ? "alert" : "status"}
      className={`rounded-sm border px-4 py-3 font-body text-sm ${TONE_CLASSES[tone]}`}
    >
      {children}
    </div>
  );
}
