export default function SummaryCard({
  label,
  value,
}: {
  label: string;
  value: number;
}) {
  return (
    <div className="rounded-md border border-line bg-white p-5 shadow-panel">
      <p className="text-sm text-muted">{label}</p>
      <p className="mt-2 font-display text-3xl font-bold tabular-nums text-navy-900">
        {value}
      </p>
    </div>
  );
}
