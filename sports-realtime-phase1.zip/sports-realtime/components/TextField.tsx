import { InputHTMLAttributes } from "react";

interface TextFieldProps extends InputHTMLAttributes<HTMLInputElement> {
  label: string;
  id: string;
}

export default function TextField({ label, id, ...rest }: TextFieldProps) {
  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={id} className="font-body text-sm font-medium text-ink">
        {label}
      </label>
      <input
        id={id}
        {...rest}
        className="rounded-sm border border-line bg-white px-3 py-2.5 font-body text-sm text-ink outline-none transition focus:border-navy-900"
      />
    </div>
  );
}
