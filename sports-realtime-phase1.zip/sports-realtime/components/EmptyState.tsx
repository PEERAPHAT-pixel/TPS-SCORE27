export default function EmptyState({
  message,
  description,
}: {
  message: string;
  description?: string;
}) {
  return (
    <div className="flex flex-col items-center justify-center rounded-md border-2 border-dashed border-navy-800/20 bg-navy-950 px-6 py-14 text-center">
      <div className="mb-4 flex items-center gap-2">
        <span
          aria-hidden
          className="h-2 w-2 rounded-full bg-amber-500 animate-pulse-dot"
        />
        <span className="font-display text-xs font-medium uppercase tracking-[0.2em] text-amber-500/80">
          Standby
        </span>
      </div>

      {/* สกอร์บอร์ดจำลองที่ยังไม่มีข้อมูล */}
      <div
        aria-hidden
        className="mb-5 font-display text-4xl font-bold tabular-nums text-white/15 sm:text-5xl"
      >
        -- : --
      </div>

      <p className="font-display text-base font-medium text-white sm:text-lg">
        {message}
      </p>
      {description ? (
        <p className="mt-1.5 max-w-sm text-sm text-white/50">{description}</p>
      ) : null}
    </div>
  );
}
