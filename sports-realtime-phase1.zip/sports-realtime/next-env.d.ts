/// <reference types="next" />
/// <reference types="next/image-types/global" />

// NOTE: ไฟล์นี้ถูกสร้างและดูแลโดย Next.js โดยอัตโนมัติเมื่อรัน `next dev`
// ไม่ต้องแก้ไขไฟล์นี้ด้วยมือ
