# ระบบรายงานผลการแข่งขันกีฬาแบบ Realtime — PHASE 1

โครงสร้างเว็บไซต์เบื้องต้น (UI + Routing) ยังไม่มี Database / Realtime / Upload / คะแนนจริง

## Stack ที่ใช้
- Next.js 14 (App Router) + TypeScript
- Tailwind CSS
- ฟอนต์: Kanit (หัวเรื่อง/ตัวเลข) + IBM Plex Sans Thai (เนื้อหา) โหลดผ่าน `next/font/google`

Stack นี้ถูกเลือกเพราะรองรับทั้ง Frontend และ API Routes (Backend) ในโปรเจกต์เดียว
ซึ่งจะใช้ต่อยอดใน PHASE 2 เป็นต้นไป (Database, Auth ฝั่ง Server, Realtime)

## วิธี Run

```bash
npm install
npm run dev
```

เปิดเบราว์เซอร์ที่ http://localhost:3000

## หน้าที่มีให้ทดสอบ

| หน้า | Path |
|---|---|
| Public Home | `/` |
| Admin Login | `/admin/login` |
| Admin Dashboard | `/admin/dashboard` |

## วิธีทดสอบ PHASE 1

1. **หน้า Public (`/`)**
   - เปิดเว็บได้โดยไม่ต้อง Login
   - เห็นชื่อการแข่งขันที่ Header
   - เห็นแท็บเมนู "ทั้งหมด"
   - เห็นข้อความ "ยังไม่มีการแข่งขัน" (ไม่มีข้อมูลตัวอย่างใดๆ)
   - ลดขนาดหน้าจอ / เปิดบนมือถือ → Layout ต้องปรับตาม (Responsive)

2. **หน้า Admin Login (`/admin/login`)**
   - กรอกชื่อผู้ใช้/รหัสผ่านอะไรก็ได้แล้วกด "เข้าสู่ระบบ"
   - ปุ่มต้องแสดง Loading State ระหว่างส่งคำขอ
   - เนื่องจากยังไม่มีระบบยืนยันตัวตนจริง (จะสร้างใน PHASE 3/9) ระบบจะแสดง
     Error State ว่า "ระบบยืนยันตัวตนยังไม่เปิดใช้งานใน Phase นี้" — **นี่คือ
     พฤติกรรมที่ถูกต้องของ Phase 1** ไม่ใช่ Bug
   - ตรวจสอบ Source Code / Network tab: **ไม่มี Password จริงฝังอยู่ใน
     Frontend** การตรวจสอบทั้งหมดเกิดที่ `/api/admin/login` ฝั่ง Server

3. **หน้า Admin Dashboard (`/admin/dashboard`)**
   - เข้าถึงได้โดยตรงในตอนนี้ (ยังไม่มีระบบป้องกันสิทธิ์ — มี Banner แจ้งไว้
     ชัดเจนบนหน้าจอ) การป้องกันจริงจะเพิ่มใน PHASE 3/9 ผ่าน Middleware ที่
     ตรวจสอบ Session ฝั่ง Server
   - เห็น Sidebar เมนู: กีฬา / ทีม / การแข่งขัน / ตารางคะแนนรวม / สรุปเหรียญ
     (ยังไม่ใช่ปุ่มที่ทำงานได้ — ระบุ "เร็วๆ นี้" ไว้อย่างชัดเจน ไม่ใช่ปุ่มลอยไม่มี
     หน้าที่)
   - เห็นการ์ดสรุปตัวเลข (กีฬา / ทีม / การแข่งขัน ฯลฯ) เป็น 0 ทั้งหมด เพราะยังไม่
     เชื่อมต่อฐานข้อมูล

## หมายเหตุด้านความปลอดภัย (เตรียมพร้อมสำหรับ PHASE 9)

- ไม่มีการเก็บ `ADMIN_PASSWORD` หรือ secret ใดๆ ไว้ใน source code/Frontend
- การตรวจสอบสิทธิ์ทั้งหมดถูกออกแบบให้เกิดที่ API Route ฝั่ง Server
  (`app/api/admin/login/route.ts`) ตั้งแต่ Phase แรก แม้ logic จริงจะยังไม่ถูก
  ใส่จนกว่าจะถึง Phase 3/9

## ยังไม่ได้ทำใน Phase นี้ (ตามแผน)
- Database (Phase 2)
- Realtime (Phase 5)
- Upload รูปภาพ (Phase 8)
- ระบบคะแนนจริง / เหรียญจริง (Phase 6, 7)
- ระบบยืนยันตัวตนจริงและการป้องกันสิทธิ์ (Phase 3, 9)
