import { NextResponse } from "next/server";

/**
 * Phase 1: endpoint นี้เป็นเพียงโครงสร้างเพื่อให้หน้า Login เรียกใช้งานได้จริง
 * (ไม่ใช่ปุ่มที่ไม่มี function) แต่ระบบยืนยันตัวตนจริงยังไม่ถูกสร้าง
 *
 * ตามกฎ PHASE 9 (Security):
 * - ห้ามเก็บรหัสผ่านจริงไว้ใน Source Code หรือ Frontend
 * - การตรวจสอบสิทธิ์ต้องทำที่ฝั่ง Server เท่านั้น
 * ดังนั้น route นี้จึงถูกวางไว้ที่ฝั่ง Server ตั้งแต่ Phase 1
 * และจะถูกเติม logic การตรวจสอบจริง (เทียบกับฐานข้อมูล + hash รหัสผ่าน
 * + ออก session/JWT แบบ httpOnly cookie) ใน PHASE 3 และ PHASE 9
 */
export async function POST() {
  return NextResponse.json(
    {
      ok: false,
      error:
        "ระบบยืนยันตัวตนยังไม่เปิดใช้งานใน Phase นี้ (จะเชื่อมต่อ Backend จริงใน Phase 3)",
    },
    { status: 501 }
  );
}
