import type { Metadata } from "next";
import { Kanit, IBM_Plex_Sans_Thai } from "next/font/google";
import "./globals.css";

// ฟอนต์หัวเรื่อง / ตัวเลขสกอร์ — ทรงเรขาคณิต หนักแน่น สไตล์ป้ายสนามกีฬา
const kanit = Kanit({
  subsets: ["thai", "latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-kanit",
  display: "swap",
});

// ฟอนต์เนื้อหา — อ่านง่ายทั้งไทยและอังกฤษ
const plexThai = IBM_Plex_Sans_Thai({
  subsets: ["thai", "latin"],
  weight: ["400", "500", "600"],
  variable: "--font-plex-thai",
  display: "swap",
});

export const metadata: Metadata = {
  title: "ระบบรายงานผลการแข่งขันกีฬา",
  description: "ระบบรายงานผลการแข่งขันกีฬาแบบ Realtime",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="th" className={`${kanit.variable} ${plexThai.variable}`}>
      <body className="min-h-screen antialiased">{children}</body>
    </html>
  );
}
