import Header from "@/components/Header";
import NavMenu from "@/components/NavMenu";
import Container from "@/components/Container";
import SectionTitle from "@/components/SectionTitle";
import EmptyState from "@/components/EmptyState";

export default function PublicHomePage() {
  return (
    <main className="min-h-screen">
      <Header />
      <NavMenu />

      <Container>
        <SectionTitle>การแข่งขัน</SectionTitle>

        {/*
          Phase 1: ยังไม่เชื่อมต่อฐานข้อมูล จึงยังไม่มีการแข่งขันเสมอ
          Phase 2+ จะดึงรายการจากตาราง matches มาแสดงแทน EmptyState นี้
        */}
        <EmptyState
          message="ยังไม่มีการแข่งขัน"
          description="เมื่อผู้ดูแลระบบเพิ่มการแข่งขัน รายการจะแสดงที่นี่โดยอัตโนมัติ"
        />
      </Container>

      <footer className="mt-16 border-t border-line py-6">
        <Container>
          <p className="text-center text-xs text-muted">
            ระบบรายงานผลการแข่งขันกีฬาแบบ Realtime — Phase 1
          </p>
        </Container>
      </footer>
    </main>
  );
}
