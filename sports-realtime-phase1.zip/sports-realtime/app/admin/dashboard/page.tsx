import Container from "@/components/Container";
import SummaryCard from "@/components/SummaryCard";
import AlertBanner from "@/components/AlertBanner";

export default function AdminDashboardPage() {
  return (
    <Container className="max-w-none py-8">
      <div className="mb-6">
        <h1 className="font-display text-2xl font-semibold text-navy-900">
          ภาพรวม
        </h1>
        <p className="mt-1 text-sm text-muted">
          สรุปข้อมูลทั้งหมดในระบบ ณ ขณะนี้
        </p>
      </div>

      <div className="mb-6">
        <AlertBanner tone="info">
          Phase 1: หน้านี้เป็นโครงสร้าง UI เท่านั้น ยังไม่เชื่อมต่อฐานข้อมูล
          และยังไม่มีการตรวจสอบสิทธิ์ผู้ดูแลระบบ (ระบบยืนยันตัวตนจะเปิดใช้งานใน
          Phase 3 และ Phase 9)
        </AlertBanner>
      </div>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
        <SummaryCard label="กีฬา" value={0} />
        <SummaryCard label="ทีม" value={0} />
        <SummaryCard label="การแข่งขัน" value={0} />
        <SummaryCard label="รายการคะแนนรวม" value={0} />
        <SummaryCard label="รายการเหรียญ" value={0} />
      </div>
    </Container>
  );
}
