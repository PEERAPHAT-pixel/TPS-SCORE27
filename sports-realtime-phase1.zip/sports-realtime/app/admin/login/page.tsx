"use client";

import { FormEvent, useState } from "react";
import Link from "next/link";
import Container from "@/components/Container";
import TextField from "@/components/TextField";
import Button from "@/components/Button";
import AlertBanner from "@/components/AlertBanner";

type Status = "idle" | "loading" | "error" | "success";

export default function AdminLoginPage() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [status, setStatus] = useState<Status>("idle");
  const [errorMessage, setErrorMessage] = useState("");

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setStatus("loading");
    setErrorMessage("");

    try {
      // สำคัญ: ไม่มี password จริงฝังอยู่ใน source code ฝั่งนี้เลย
      // ทุกการตรวจสอบเกิดขึ้นที่ /api/admin/login (ฝั่ง Server) เท่านั้น
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });

      const data = await res.json();

      if (!res.ok || !data.ok) {
        setStatus("error");
        setErrorMessage(data.error ?? "เข้าสู่ระบบไม่สำเร็จ");
        return;
      }

      setStatus("success");
    } catch {
      setStatus("error");
      setErrorMessage("ไม่สามารถเชื่อมต่อกับเซิร์ฟเวอร์ได้ กรุณาลองใหม่อีกครั้ง");
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-navy-950 px-4 py-12">
      <Container className="max-w-sm">
        <div className="rounded-md bg-white p-6 shadow-panel sm:p-8">
          <div className="mb-6 text-center">
            <span
              aria-hidden
              className="mx-auto mb-3 inline-flex h-10 w-10 items-center justify-center rounded-sm border-2 border-amber-500 font-display text-sm font-bold text-navy-900"
            >
              ⚑
            </span>
            <h1 className="font-display text-xl font-semibold text-navy-900">
              เข้าสู่ระบบผู้ดูแล
            </h1>
            <p className="mt-1 text-sm text-muted">
              สำหรับผู้ดูแลระบบเท่านั้น
            </p>
          </div>

          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <TextField
              id="username"
              label="ชื่อผู้ใช้"
              type="text"
              autoComplete="username"
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              disabled={status === "loading"}
            />
            <TextField
              id="password"
              label="รหัสผ่าน"
              type="password"
              autoComplete="current-password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={status === "loading"}
            />

            {status === "error" ? (
              <AlertBanner tone="error">{errorMessage}</AlertBanner>
            ) : null}
            {status === "success" ? (
              <AlertBanner tone="success">เข้าสู่ระบบสำเร็จ</AlertBanner>
            ) : null}

            <Button type="submit" isLoading={status === "loading"} className="mt-1">
              เข้าสู่ระบบ
            </Button>
          </form>
        </div>

        <p className="mt-4 text-center">
          <Link href="/" className="text-sm text-white/60 hover:text-white">
            ← กลับสู่หน้าหลัก
          </Link>
        </p>
      </Container>
    </main>
  );
}
