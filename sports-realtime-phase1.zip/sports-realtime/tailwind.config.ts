import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // ธีม "Scoreboard" — ได้แรงบันดาลใจจากจอสกอร์บอร์ดสนามกีฬาจริง
        navy: {
          950: "#0B1830", // พื้นหลังแถบควบคุม / sidebar admin
          900: "#10214B", // สีหลักของแบรนด์ (header, ปุ่มหลัก)
          800: "#182D63",
          700: "#22397C",
        },
        amber: {
          500: "#FF8A00", // สถานะ "กำลังแข่งขัน" / live accent
          400: "#FFA733",
        },
        emerald: {
          600: "#128A5E",
          500: "#17A673", // สถานะ "จบการแข่งขัน" / success
        },
        rose: {
          500: "#E5484D", // สถานะ "ยกเลิก" / error
        },
        ink: "#10151F",
        muted: "#5B6472",
        line: "#E1E4E0",
        surface: "#F5F6F4",
      },
      fontFamily: {
        display: ["var(--font-kanit)", "sans-serif"],
        body: ["var(--font-plex-thai)", "sans-serif"],
      },
      boxShadow: {
        panel: "0 1px 2px 0 rgb(16 21 31 / 0.04), 0 1px 12px -2px rgb(16 21 31 / 0.06)",
      },
      keyframes: {
        pulseDot: {
          "0%, 100%": { opacity: "1" },
          "50%": { opacity: "0.35" },
        },
      },
      animation: {
        "pulse-dot": "pulseDot 1.8s ease-in-out infinite",
      },
    },
  },
  plugins: [],
};

export default config;
